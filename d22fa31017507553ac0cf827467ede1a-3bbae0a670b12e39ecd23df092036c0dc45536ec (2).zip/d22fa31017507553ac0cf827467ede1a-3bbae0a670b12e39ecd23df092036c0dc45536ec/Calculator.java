import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите выражение (например, 2+2): ");
        String input = scanner.nextLine().replaceAll("\\s+", "");

        int result = 0;
        if (input.contains("+")) {
            String[] parts = input.split("\\+");
            result = Integer.parseInt(parts[0]) + Integer.parseInt(parts[1]);
        } else if (input.contains("-")) {
            String[] parts = input.split("-");
            result = Integer.parseInt(parts[0]) - Integer.parseInt(parts[1]);
        } else if (input.contains("*")) {
            String[] parts = input.split("\\*");
            result = Integer.parseInt(parts[0]) * Integer.parseInt(parts[1]);
        } else if (input.contains("/")) {
            String[] parts = input.split("/");
            result = Integer.parseInt(parts[0]) / Integer.parseInt(parts[1]);
        } else {
            System.out.println("Некорректное выражение!");
            return;
        }

        System.out.println("Результат: " + result);
    }
}
